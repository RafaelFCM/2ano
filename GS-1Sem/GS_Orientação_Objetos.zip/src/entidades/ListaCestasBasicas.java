package entidades;

public class ListaCestasBasicas{
    private static int quant_cestas = 100;

    public static int getQuant_cestas() {
        return quant_cestas;
    }
    
}

